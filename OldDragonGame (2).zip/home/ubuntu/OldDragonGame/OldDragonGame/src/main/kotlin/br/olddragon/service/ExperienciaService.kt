package br.olddragon.service

import br.olddragon.model.personagem.Personagem
import br.olddragon.model.utils.TabelasOD

class ExperienciaService {

    fun adicionarExperiencia(personagem: Personagem, xp: Int): String {
        // Lógica para adicionar XP e verificar subida de nível
        return "${personagem.nome} ganhou $xp pontos de experiência."
    }
}


