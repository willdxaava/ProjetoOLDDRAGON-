package br.olddragon.model.utils

// Este objeto pode conter tabelas de referência do Old Dragon, como XP por nível, etc.
object TabelasOD {
    val xpPorNivel = mapOf(
        1 to 0,
        2 to 1200,
        3 to 2400,
        4 to 4800,
        5 to 9600
        // ... e assim por diante
    )
}


