package br.olddragon.model.personagem

enum class Alinhamento(val nomePortugues: String) {
    LEAL_BOM("Leal e Bom"),
    LEAL_NEUTRO("Leal e Neutro"),
    LEAL_MAU("Leal e Mau"),
    NEUTRO_BOM("Neutro e Bom"),
    NEUTRO("Neutro"),
    NEUTRO_MAU("Neutro e Mau"),
    CAOTICO_BOM("Caótico e Bom"),
    CAOTICO_NEUTRO("Caótico e Neutro"),
    CAOTICO_MAU("Caótico e Mau")
}


