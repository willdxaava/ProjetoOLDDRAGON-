package br.olddragon.service

import br.olddragon.model.personagem.Personagem
import br.olddragon.model.utils.Dado

class CombateService {

    fun atacar(atacante: Personagem, defensor: Personagem): String {
        val rolagemAtaque = Dado.rolarD6(1) + atacante.bonusAtaque() // Usando a nova função
        return if (rolagemAtaque >= defensor.classeArmadura) {
            "${atacante.nome} acertou ${defensor.nome}!"
        } else {
            "${atacante.nome} errou o ataque!"
        }
    }
}


