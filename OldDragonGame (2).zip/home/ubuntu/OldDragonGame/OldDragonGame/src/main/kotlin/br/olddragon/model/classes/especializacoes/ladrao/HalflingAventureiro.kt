package br.olddragon.model.classes.especializacoes.ladrao

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class HalflingAventureiro : EspecializacaoClasse {
    override val nomePortugues: String = "Halfling Aventureiro"
    override val habilidades: List<String> = listOf("Sorte Halfling", "Furtividade Natural")
}


