package br.olddragon.model.classes.especializacoes.ladrao

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Ranger : EspecializacaoClasse {
    override val nomePortugues: String = "Ranger"
    override val habilidades: List<String> = listOf("Rastreamento", "Conhecimento da Natureza")
}


