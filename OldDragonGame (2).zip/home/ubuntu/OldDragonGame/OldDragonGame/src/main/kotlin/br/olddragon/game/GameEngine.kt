package br.olddragon.game

// Classe principal para orquestrar o fluxo do jogo
class GameEngine {
    fun iniciarJogo() {
        println("Iniciando o motor do jogo...")
        // Aqui pode vir a lógica principal do jogo, como carregar estados, etc.
    }
}


