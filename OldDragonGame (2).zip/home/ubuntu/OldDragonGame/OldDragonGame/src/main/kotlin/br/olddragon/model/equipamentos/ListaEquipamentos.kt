package br.olddragon.model.equipamentos

object ListaEquipamentos {
    val armas = listOf(
        Arma("Espada Longa", "1d8", "Corte", 1.5, 15),
        Arma("Adaga", "1d4", "Perfurante", 0.5, 2),
        Arma("Arco Curto", "1d6", "Perfurante", 1.0, 25)
    )

    val armaduras = listOf(
        Armadura("Armadura de Couro", 2, "Leve", 5.0, 10),
        Armadura("Cota de Malha", 4, "Média", 20.0, 40),
        Armadura("Armadura Completa", 6, "Pesada", 50.0, 200)
    )

    val itens = listOf(
        Item("Mochila", "Capacidade para carregar itens.", 1.0, 2),
        Item("Tocha", "Fonte de luz.", 0.5, 1),
        Item("Rações de Viagem", "Comida para um dia.", 0.5, 0)
    )
}


