package br.olddragon

import br.olddragon.service.PersonagemService
import br.olddragon.ui.MenuPrincipal

fun main() {
    val personagemService = PersonagemService()
    val menuPrincipal = MenuPrincipal(personagemService)
    menuPrincipal.iniciar()
}


