package br.olddragon.model.magias

enum class EscolaMagia(val nome: String) {
    ABJURACAO("Abjuração"),
    ADIVINHACAO("Adivinhação"),
    CONJURACAO("Conjuração"),
    ENCANTAMENTO("Encantamento"),
    EVOCACAO("Evocação"),
    ILUSAO("Ilusão"),
    NECROMANCIA("Necromancia"),
    TRANSMUTACAO("Transmutação")
}


