package br.olddragon.model.magias

data class Magia(
    val nome: String,
    val nivel: Int,
    val escola: EscolaMagia,
    val descricao: String
)


