package br.olddragon.model.classes.basicas

import br.olddragon.model.classes.ClasseBase
import br.olddragon.model.classes.TipoClasse
import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Mago : ClasseBase {
    override val tipo: TipoClasse = TipoClasse.MAGO
    override val dadoVida: String = "1d4"
    override val ataqueBase: Int = 0
    override val jogadaProtecao: Int = 15
    override val habilidades: List<String> = listOf("Conjuração de Magias Arcanas")
    override val especializacao: EspecializacaoClasse? = null
}


