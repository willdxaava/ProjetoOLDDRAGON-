package br.olddragon.model.classes.especializacoes.clerigo

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Druida : EspecializacaoClasse {
    override val nomePortugues: String = "Druida"
    override val habilidades: List<String> = listOf("Magia Natural", "Forma Animal")
}


