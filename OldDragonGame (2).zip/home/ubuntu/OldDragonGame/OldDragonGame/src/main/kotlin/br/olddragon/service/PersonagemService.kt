package br.olddragon.service

import br.olddragon.model.personagem.Atributos
import br.olddragon.model.classes.ClasseBase
import br.olddragon.model.personagem.Personagem
import br.olddragon.model.personagem.Raca
import br.olddragon.model.personagem.Alinhamento

class PersonagemService {

    fun criarPersonagem(
        nome: String,
        raca: Raca,
        classe: ClasseBase,
        alinhamento: Alinhamento,
        atributos: Atributos
    ): Personagem {
        return Personagem(nome, raca, classe, alinhamento, atributos)
    }
}


