package br.olddragon.model.classes.especializacoes.mago

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Bruxo : EspecializacaoClasse {
    override val nomePortugues: String = "Bruxo"
    override val habilidades: List<String> = listOf("Pacto Sobrenatural", "Maldições")
}


