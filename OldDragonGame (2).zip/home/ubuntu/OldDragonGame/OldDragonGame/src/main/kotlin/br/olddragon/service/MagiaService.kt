package br.olddragon.service

import br.olddragon.model.magias.Magia
import br.olddragon.model.personagem.Personagem

class MagiaService {

    fun conjurarMagia(personagem: Personagem, magia: Magia): String {
        return "${personagem.nome} conjurou ${magia.nome}! Efeito: ${magia.descricao}"
    }
}


