package br.olddragon.model.classes.especializacoes.clerigo

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Proscrito : EspecializacaoClasse {
    override val nomePortugues: String = "Proscrito"
    override val habilidades: List<String> = listOf("Furtividade Urbana", "Sobrevivência na Rua")
}


