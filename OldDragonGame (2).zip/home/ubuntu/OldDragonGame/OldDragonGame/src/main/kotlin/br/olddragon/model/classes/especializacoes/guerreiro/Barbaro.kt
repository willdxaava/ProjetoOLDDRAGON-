package br.olddragon.model.classes.especializacoes.guerreiro

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Barbaro : EspecializacaoClasse {
    override val nomePortugues: String = "Bárbaro"
    override val habilidades: List<String> = listOf("Fúria Selvagem", "Resistência Natural")
}


