package br.olddragon.model.classes

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

enum class TipoClasse(val nomePortugues: String) {
    GUERREIRO("Guerreiro"),
    CLERIGO("Clérigo"),
    LADRAO("Ladrão"),
    MAGO("Mago")
}

interface ClasseBase {
    val tipo: TipoClasse
    val dadoVida: String
    val ataqueBase: Int
    val jogadaProtecao: Int
    val habilidades: List<String>
    val especializacao: EspecializacaoClasse?
}


