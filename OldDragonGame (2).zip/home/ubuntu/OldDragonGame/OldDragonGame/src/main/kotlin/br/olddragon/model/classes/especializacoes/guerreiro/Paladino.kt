package br.olddragon.model.classes.especializacoes.guerreiro

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Paladino : EspecializacaoClasse {
    override val nomePortugues: String = "Paladino"
    override val habilidades: List<String> = listOf("Aura de Proteção", "Curar Doenças")
}


