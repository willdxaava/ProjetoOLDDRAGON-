package br.olddragon.model.personagem

enum class Raca(val nomePortugues: String, val movimento: Int, val tamanho: String) {
    HUMANO("Humano", 9, "Médio"),
    ELFO("Elfo", 9, "Médio"),
    ANAO("Anão", 6, "Médio"),
    HALFLING("Halfling", 6, "Pequeno")
}


