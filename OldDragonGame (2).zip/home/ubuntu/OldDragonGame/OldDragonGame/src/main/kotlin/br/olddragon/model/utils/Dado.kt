package br.olddragon.model.utils

import kotlin.random.Random

object Dado {
    fun rolarD6(quantidade: Int): Int {
        var total = 0
        repeat(quantidade) {
            total += Random.nextInt(1, 7) // Rola um d6 (1 a 6)
        }
        return total
    }

    fun rolar4d6DescartaMenor(): Int {
        val rolagens = mutableListOf<Int>()
        repeat(4) {
            rolagens.add(Random.nextInt(1, 7))
        }
        rolagens.remove(rolagens.minOrNull())
        return rolagens.sum()
    }
}


