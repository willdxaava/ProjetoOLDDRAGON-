package br.olddragon.model.magias

object ListaMagias {
    val magias = listOf(
        Magia("Bola de Fogo", 3, EscolaMagia.EVOCACAO, "Causa dano de fogo em área."),
        Magia("Curar Ferimentos Leves", 1, EscolaMagia.CONJURACAO, "Cura uma pequena quantidade de pontos de vida."),
        Magia("Mísseis Mágicos", 1, EscolaMagia.EVOCACAO, "Dispara projéteis de energia mágica.")
    )
}


