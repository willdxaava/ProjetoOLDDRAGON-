package br.olddragon.model.utils

import br.olddragon.model.personagem.Atributos

object GeradorPersonagem {

    fun gerarAtributosClassico(): Atributos {
        // 3d6 em ordem
        return Atributos(
            forca = Dado.rolarD6(3),
            destreza = Dado.rolarD6(3),
            constituicao = Dado.rolarD6(3),
            inteligencia = Dado.rolarD6(3),
            sabedoria = Dado.rolarD6(3),
            carisma = Dado.rolarD6(3)
        )
    }

    fun gerarAtributosAventureiro(): Atributos {
        // 4d6, descarta o menor
        return Atributos(
            forca = Dado.rolar4d6DescartaMenor(),
            destreza = Dado.rolar4d6DescartaMenor(),
            constituicao = Dado.rolar4d6DescartaMenor(),
            inteligencia = Dado.rolar4d6DescartaMenor(),
            sabedoria = Dado.rolar4d6DescartaMenor(),
            carisma = Dado.rolar4d6DescartaMenor()
        )
    }

    fun gerarAtributosHeroico(valores: List<Int>): Atributos {
        // 6 valores para distribuir
        require(valores.size == 6) { "Devem ser fornecidos 6 valores." }
        val shuffledValores = valores.shuffled()
        return Atributos(
            forca = shuffledValores[0],
            destreza = shuffledValores[1],
            constituicao = shuffledValores[2],
            inteligencia = shuffledValores[3],
            sabedoria = shuffledValores[4],
            carisma = shuffledValores[5]
        )
    }
}


