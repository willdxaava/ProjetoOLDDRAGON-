package br.olddragon.model.classes.especializacoes

interface EspecializacaoClasse {
    val nomePortugues: String
    val habilidades: List<String>
}


