package br.olddragon.ui

import br.olddragon.model.personagem.Atributos
import br.olddragon.model.classes.ClasseBase
import br.olddragon.model.personagem.Personagem
import br.olddragon.model.personagem.Raca
import br.olddragon.model.utils.GeradorPersonagem
import br.olddragon.service.PersonagemService
import br.olddragon.model.classes.basicas.Guerreiro
import br.olddragon.model.classes.basicas.Clerigo
import br.olddragon.model.classes.basicas.Ladrao
import br.olddragon.model.classes.basicas.Mago
import br.olddragon.model.personagem.Alinhamento
import java.util.Scanner

class CriacaoPersonagemUI(private val personagemService: PersonagemService) {

    private val scanner = Scanner(System.`in`)

    fun criarPersonagemAleatorio(): Personagem {
        println("\n--- CRIAÇÃO DE PERSONAGEM ALEATÓRIO ---")
        val nome = "Aventureiro Aleatório " + (1000..9999).random()
        val raca = Raca.values().random()
        val classe = listOf(Guerreiro(), Clerigo(), Ladrao(), Mago()).random()
        val alinhamento = Alinhamento.values().random()
        val atributos = GeradorPersonagem.gerarAtributosAventureiro() // Ou Clássico, ou Heróico com valores fixos

        println("Gerando personagem aleatório...")
        return personagemService.criarPersonagem(nome, raca, classe, alinhamento, atributos)
    }

    fun criarPersonagemCustomizado(): Personagem {
        println("\n--- CRIAÇÃO DE PERSONAGEM CUSTOMIZADO ---")

        print("Digite o nome do seu personagem: ")
        val nome = scanner.nextLine().trim()

        val raca = selecionarRaca()
        val classe = selecionarClasse()
        val alinhamento = selecionarAlinhamento()
        val atributos = gerarAtributos()

        return personagemService.criarPersonagem(nome, raca, classe, alinhamento, atributos)
    }

    private fun selecionarRaca(): Raca {
        while (true) {
            println("\n╔══════════════ SELECIONE A RAÇA ═══════════════╗")
            Raca.values().forEachIndexed { index, raca ->
                println("║  ${index + 1}️⃣  ${raca.nomePortugues.padEnd(40)} ║")
            }
            println("╚═══════════════════════════════════════════════╝")
            print("Escolha uma opção: ")
            val escolha = scanner.nextLine().trim().toIntOrNull()
            if (escolha != null && escolha > 0 && escolha <= Raca.values().size) {
                return Raca.values()[escolha - 1]
            } else {
                println("❌ Opção inválida. Tente novamente.")
            }
        }
    }

    private fun selecionarClasse(): ClasseBase {
        while (true) {
            println("\n╔══════════════ SELECIONE A CLASSE ═════════════╗")
            println("║  1️⃣  Guerreiro                                ║")
            println("║  2️⃣  Clérigo                                  ║")
            println("║  3️⃣  Ladrão                                   ║")
            println("║  4️⃣  Mago                                     ║")
            println("╚═══════════════════════════════════════════════╝")
            print("Escolha uma opção: ")
            when (scanner.nextLine().trim()) {
                "1" -> return Guerreiro()
                "2" -> return Clerigo()
                "3" -> return Ladrao()
                "4" -> return Mago()
                else -> println("❌ Opção inválida. Tente novamente.")
            }
        }
    }

    private fun selecionarAlinhamento(): Alinhamento {
        while (true) {
            println("\n╔════════════ SELECIONE O ALINHAMENTO ══════════╗")
            Alinhamento.values().forEachIndexed { index, alinhamento ->
                println("║  ${index + 1}️⃣  ${alinhamento.nomePortugues.padEnd(35)} ║")
            }
            println("╚═══════════════════════════════════════════════╝")
            print("Escolha uma opção: ")
            val escolha = scanner.nextLine().trim().toIntOrNull()
            if (escolha != null && escolha > 0 && escolha <= Alinhamento.values().size) {
                return Alinhamento.values()[escolha - 1]
            } else {
                println("❌ Opção inválida. Tente novamente.")
            }
        }
    }

    private fun gerarAtributos(): Atributos {
        while (true) {
            println("\n╔════════════ SELECIONE O MÉTODO DE ATRIBUTOS ══════════╗")
            println("║  1️⃣  Clássico (3d6 em ordem)                           ║")
            println("║  2️⃣  Aventureiro (4d6, descarta o menor)               ║")
            println("║  3️⃣  Heróico (6 valores para distribuir)               ║")
            println("╚═══════════════════════════════════════════════════════╝")
            print("Escolha uma opção: ")

            when (scanner.nextLine().trim()) {
                "1" -> {
                    println("Gerando atributos pelo método Clássico...")
                    return GeradorPersonagem.gerarAtributosClassico()
                }
                "2" -> {
                    println("Gerando atributos pelo método Aventureiro...")
                    return GeradorPersonagem.gerarAtributosAventureiro()
                }
                "3" -> {
                    println("Gerando atributos pelo método Heróico.")
                    println("Digite 6 valores inteiros separados por espaço (ex: 18 16 14 12 10 8): ")
                    val input = scanner.nextLine().trim()
                    try {
                        val valores = input.split(" ").map { it.toInt() }
                        if (valores.size == 6) {
                            return GeradorPersonagem.gerarAtributosHeroico(valores)
                        } else {
                            println("Você deve fornecer exatamente 6 valores. Tente novamente.")
                        }
                    } catch (e: NumberFormatException) {
                        println("Entrada inválida. Certifique-se de digitar apenas números inteiros. Tente novamente.")
                    }
                }
                else -> println("❌ Opção inválida. Tente novamente.")
            }
        }
    }
}


