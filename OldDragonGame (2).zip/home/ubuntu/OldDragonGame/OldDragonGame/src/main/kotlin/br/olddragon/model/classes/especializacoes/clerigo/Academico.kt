package br.olddragon.model.classes.especializacoes.clerigo

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Academico : EspecializacaoClasse {
    override val nomePortugues: String = "Acadêmico"
    override val habilidades: List<String> = listOf("Conhecimento Erudito", "Pesquisa Avançada")
}


