package br.olddragon.model.classes.especializacoes.mago

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class ElfoAventureiro : EspecializacaoClasse {
    override val nomePortugues: String = "Elfo Aventureiro"
    override val habilidades: List<String> = listOf("Sentidos Aguçados", "Magia Natural")
}


