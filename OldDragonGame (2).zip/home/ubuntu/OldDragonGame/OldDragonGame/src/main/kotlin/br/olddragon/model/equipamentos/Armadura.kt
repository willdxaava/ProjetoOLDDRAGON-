package br.olddragon.model.equipamentos

data class Armadura(
    val nome: String,
    val caBonus: Int,
    val tipo: String,
    val peso: Double,
    val preco: Int
)


