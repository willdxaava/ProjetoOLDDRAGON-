package br.olddragon.model.equipamentos

data class Item(
    val nome: String,
    val descricao: String,
    val peso: Double,
    val preco: Int
)


