package br.olddragon.game

// Representa o estado atual do jogo (personagens ativos, localização, etc.)
data class EstadoJogo(
    val personagensAtivos: MutableList<br.olddragon.model.personagem.Personagem> = mutableListOf(),
    var localizacaoAtual: String = "Cidade Inicial"
)


