package br.olddragon.model.classes.especializacoes.guerreiro

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class AnaoAventureiro : EspecializacaoClasse {
    override val nomePortugues: String = "Anão Aventureiro"
    override val habilidades: List<String> = listOf("Resistência Anã", "Conhecimento de Rochas")
}


