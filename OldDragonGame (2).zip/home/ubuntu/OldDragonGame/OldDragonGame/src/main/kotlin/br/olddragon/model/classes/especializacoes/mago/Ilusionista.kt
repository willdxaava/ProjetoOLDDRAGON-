package br.olddragon.model.classes.especializacoes.mago

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Ilusionista : EspecializacaoClasse {
    override val nomePortugues: String = "Ilusionista"
    override val habilidades: List<String> = listOf("Magias de Ilusão", "Enganação")
}


