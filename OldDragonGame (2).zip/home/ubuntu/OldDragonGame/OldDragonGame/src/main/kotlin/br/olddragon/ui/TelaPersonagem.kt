package br.olddragon.ui

import br.olddragon.model.personagem.Personagem

class TelaPersonagem {
    fun exibirDetalhes(personagem: Personagem) {
        println("\n--- DETALHES DO PERSONAGEM ---")
        println(personagem.resumo())
        println("------------------------------")
    }
}


