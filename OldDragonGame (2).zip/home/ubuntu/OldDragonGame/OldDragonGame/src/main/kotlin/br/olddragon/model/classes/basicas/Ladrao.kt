package br.olddragon.model.classes.basicas

import br.olddragon.model.classes.ClasseBase
import br.olddragon.model.classes.TipoClasse
import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Ladrao : ClasseBase {
    override val tipo: TipoClasse = TipoClasse.LADRAO
    override val dadoVida: String = "1d4"
    override val ataqueBase: Int = 0
    override val jogadaProtecao: Int = 13
    override val habilidades: List<String> = listOf("Abrir Fechaduras", "Desarmar Armadilhas", "Esconder-se")
    override val especializacao: EspecializacaoClasse? = null
}


