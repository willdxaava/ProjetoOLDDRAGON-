package br.olddragon.game

// Configurações globais do jogo
object ConfiguracaoJogo {
    const val VERSAO_JOGO = "1.0.0"
    const val NOME_JOGO = "Old Dragon RPG - Aventuras Clássicas"
}


