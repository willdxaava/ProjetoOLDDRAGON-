package br.olddragon.model.classes.basicas

import br.olddragon.model.classes.ClasseBase
import br.olddragon.model.classes.TipoClasse
import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Guerreiro : ClasseBase {
    override val tipo: TipoClasse = TipoClasse.GUERREIRO
    override val dadoVida: String = "1d8"
    override val ataqueBase: Int = 1
    override val jogadaProtecao: Int = 14
    override val habilidades: List<String> = listOf("Especialização em Armas")
    override val especializacao: EspecializacaoClasse? = null
}


