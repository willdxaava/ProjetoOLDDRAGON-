package br.olddragon.model.classes.especializacoes.clerigo

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Xama : EspecializacaoClasse {
    override val nomePortugues: String = "Xamã"
    override val habilidades: List<String> = listOf("Comunhão com Espíritos", "Cura Espiritual")
}


