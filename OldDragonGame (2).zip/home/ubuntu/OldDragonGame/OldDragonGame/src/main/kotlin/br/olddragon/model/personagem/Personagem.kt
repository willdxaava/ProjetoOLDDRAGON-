package br.olddragon.model.personagem

import br.olddragon.model.classes.ClasseBase

data class Personagem(
    val nome: String,
    val raca: Raca,
    val classeBase: ClasseBase,
    val alinhamento: Alinhamento,
    val atributos: Atributos,
    var pontosVida: Int = 0,
    var pontosVidaMaximos: Int = 0,
    var classeArmadura: Int = 0,
    var ouro: Int = 0,
    var experiencia: Int = 0,
    var nivel: Int = 1
) {

    fun bonusAtaque(): Int {
        // Implementar cálculo de bônus de ataque baseado na classe e atributos
        return 0 // Placeholder
    }

    fun getHabilidadesEspeciais(): List<String> {
        // Implementar obtenção de habilidades especiais da classe e raça
        return listOf("Nenhuma") // Placeholder
    }

    fun magiaInfo(): String {
        // Implementar informações sobre magia (PM, magias por nível, etc.)
        return "PM: 0/0" // Placeholder
    }

    fun resumo(): String {
        val especializacao = classeBase.especializacao?.let { " (${it.nomePortugues})" } ?: ""
        val atributosFormatados = atributos.toString().replace("\n", " ║\n║ ")

        return """
            |╔══════════════════════════════════════════════════════════╗
            |║                   📜 ${nome.padEnd(25)}            ║
            |╠══════════════════════════════════════════════════════════╣
            |║ Raça: ${raca.nomePortugues.padEnd(15)} Nível: ${nivel.toString().padStart(2)}           ║
            |║ Classe: ${(classeBase.tipo.nomePortugues + especializacao).padEnd(25)} ║
            |║ Alinhamento: ${alinhamento.nomePortugues.padEnd(20)}        ║
            |╠══════════════════════════════════════════════════════════╣
            |║ ❤️  PV: ${pontosVida.toString().padStart(3)}/${pontosVidaMaximos.toString().padEnd(3)} 🛡️  CA: ${classeArmadura.toString().padStart(2)}  💰 ${ouro}po  XP: ${experiencia} ║
            |╠══════════════════════════════════════════════════════════╣
            |║ ${atributosFormatados} ║
            |╠══════════════════════════════════════════════════════════╣
            |║ ⚔️  Bônus Ataque: +${bonusAtaque().toString().padStart(2)}                         ║
            |║ ${magiaInfo().padEnd(52)} ║
            |║ 🎪 Habilidades: ${getHabilidadesEspecializadas().take(2).joinToString(", ").padEnd(30)} ║
            |║ 🏃 Movimento: ${raca.movimento}m   Tamanho: ${raca.tamanho.padEnd(10)}        ║
            |╚══════════════════════════════════════════════════════════╝
        """.trimMargin()
    }

    private fun getHabilidadesEspecializadas(): List<String> {
        val habilidades = mutableListOf<String>()
        habilidades.addAll(classeBase.habilidades)
        classeBase.especializacao?.let { habilidades.addAll(it.habilidades) }
        return habilidades
    }
}


