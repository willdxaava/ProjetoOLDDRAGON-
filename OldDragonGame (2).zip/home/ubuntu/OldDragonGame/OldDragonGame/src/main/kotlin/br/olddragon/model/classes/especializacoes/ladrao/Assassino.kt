package br.olddragon.model.classes.especializacoes.ladrao

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Assassino : EspecializacaoClasse {
    override val nomePortugues: String = "Assassino"
    override val habilidades: List<String> = listOf("Ataque Furtivo", "Veneno")
}


