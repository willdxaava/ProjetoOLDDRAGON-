package br.olddragon.model.classes.especializacoes.guerreiro

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Arqueiro : EspecializacaoClasse {
    override val nomePortugues: String = "Arqueiro"
    override val habilidades: List<String> = listOf("Tiro Preciso", "Olho de Águia")
}


