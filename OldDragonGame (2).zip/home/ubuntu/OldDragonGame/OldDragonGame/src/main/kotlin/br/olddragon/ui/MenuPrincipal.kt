package br.olddragon.ui

import br.olddragon.service.PersonagemService
import br.olddragon.model.personagem.Personagem
import java.util.Scanner

class MenuPrincipal(private val personagemService: PersonagemService) {

    private val scanner = Scanner(System.`in`)
    private var personagemAtual: Personagem? = null
    private val criacaoUI = CriacaoPersonagemUI(personagemService)

    fun iniciar() {
        while (true) {
            println("""
╔═══════════════════════════════════════════════════════════╗
║  🐲            OLD DRAGON SRD - KOTLIN                  🗡️ ║
║                                                           ║
║        ⚡ Baseado no Sistema de Referência Oficial ⚡     ║
║                                                           ║
║              Bem-vindo, aventureiro!                      ║
╚═══════════════════════════════════════════════════════════╝

╔══════════════ MENU PRINCIPAL OLD DRAGON SRD ═══════════════╗
║                                                             ║
║  1️⃣  Criar Personagem Aleatório                            ║
║  2️⃣  Criar Personagem Customizado                          ║
║  3️⃣  Ver Personagem Atual                                  ║
║  4️⃣  Testar Sistema de Combate                             ║
║  5️⃣  Usar Magia                                            ║
║  6️⃣  Descansar (Recuperar HP e Magias)                     ║
║  7️⃣  Ganhar Experiência                                    ║
║  0️⃣  Sair do Jogo                                          ║
║                                                             ║
╚═══════════════════════════════════════════════════════════╝
            """.trimIndent())
            print("Escolha uma opção: ")

            when (scanner.nextLine().trim()) {
                "1" -> criarPersonagemAleatorio()
                "2" -> criarPersonagemCustomizado()
                "3" -> verPersonagemAtual()
                "4" -> testarSistemaCombate()
                "5" -> usarMagia()
                "6" -> descansar()
                "7" -> ganharExperiencia()
                "0" -> {
                    println("\n🐲 Obrigado por jogar Old Dragon!")
                    println("Que suas aventuras sejam épicas!")
                    break
                }
                else -> println("❌ Opção inválida! Por favor, escolha uma opção válida.")
            }
        }
        scanner.close()
    }

    private fun criarPersonagemAleatorio() {
        try {
            personagemAtual = criacaoUI.criarPersonagemAleatorio()
            println("\n" + "=".repeat(60))
            println("🎉 PERSONAGEM ALEATÓRIO CRIADO COM SUCESSO! 🎉")
            println("=".repeat(60))
            personagemAtual?.let { println(it.resumo()) }
            println("=".repeat(60))
        } catch (e: Exception) {
            println("❌ Erro ao criar personagem aleatório: ${e.message}")
            println("Tente novamente.")
        }
        println("Pressione ENTER para continuar...")
        readlnOrNull()
    }

    private fun criarPersonagemCustomizado() {
        try {
            personagemAtual = criacaoUI.criarPersonagemCustomizado()
            println("\n" + "=".repeat(60))
            println("🎉 PERSONAGEM CUSTOMIZADO CRIADO COM SUCESSO! 🎉")
            println("=".repeat(60))
            personagemAtual?.let { println(it.resumo()) }
            println("=".repeat(60))
        } catch (e: Exception) {
            println("❌ Erro ao criar personagem customizado: ${e.message}")
            println("Tente novamente.")
        }
        println("Pressione ENTER para continuar...")
        readlnOrNull()
    }

    private fun verPersonagemAtual() {
        if (personagemAtual != null) {
            println("\n--- SEU PERSONAGEM ATUAL ---")
            println(personagemAtual!!.resumo())
        } else {
            println("\nVocê ainda não criou um personagem. Use as opções 1 ou 2 para criar um.")
        }
        println("Pressione ENTER para continuar...")
        readlnOrNull()
    }

    private fun testarSistemaCombate() {
        println("\nFuncionalidade: Testar Sistema de Combate (Ainda não implementado)")
        // Lógica para testar sistema de combate
        println("Pressione ENTER para continuar...")
        readlnOrNull()
    }

    private fun usarMagia() {
        println("\nFuncionalidade: Usar Magia (Ainda não implementado)")
        // Lógica para usar magia
        println("Pressione ENTER para continuar...")
        readlnOrNull()
    }

    private fun descansar() {
        println("\nFuncionalidade: Descansar (Ainda não implementado)")
        // Lógica para descansar
        println("Pressione ENTER para continuar...")
        readlnOrNull()
    }

    private fun ganharExperiencia() {
        println("\nFuncionalidade: Ganhar Experiência (Ainda não implementado)")
        // Lógica para ganhar experiência
        println("Pressione ENTER para continuar...")
        readlnOrNull()
    }
}


