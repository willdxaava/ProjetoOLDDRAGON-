package br.olddragon.model.personagem

data class Atributos(
    var forca: Int,
    var destreza: Int,
    var constituicao: Int,
    var inteligencia: Int,
    var sabedoria: Int,
    var carisma: Int
) {
    fun modificador(valor: Int): Int {
        return when (valor) {
            in 1..3 -> -3
            in 4..5 -> -2
            in 6..8 -> -1
            in 9..12 -> 0
            in 13..15 -> 1
            in 16..17 -> 2
            18 -> 3
            else -> 0 // Valor padrão para fora do range esperado
        }
    }

    override fun toString(): String {
        return """
            FOR: ${forca.toString().padStart(2)} (${modificador(forca).toString().padStart(2, ' ')}), DES: ${destreza.toString().padStart(2)} (${modificador(destreza).toString().padStart(2, ' ')}), CON: ${constituicao.toString().padStart(2)} (${modificador(constituicao).toString().padStart(2, ' ')})
            INT: ${inteligencia.toString().padStart(2)} (${modificador(inteligencia).toString().padStart(2, ' ')}), SAB: ${sabedoria.toString().padStart(2)} (${modificador(sabedoria).toString().padStart(2, ' ')}), CAR: ${carisma.toString().padStart(2)} (${modificador(carisma).toString().padStart(2, ' ')})
        """.trimIndent()
    }
}


