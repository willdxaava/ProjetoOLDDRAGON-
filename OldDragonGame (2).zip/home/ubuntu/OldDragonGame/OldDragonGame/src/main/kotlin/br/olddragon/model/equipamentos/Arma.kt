package br.olddragon.model.equipamentos

data class Arma(
    val nome: String,
    val dano: String,
    val tipo: String,
    val peso: Double,
    val preco: Int
)


