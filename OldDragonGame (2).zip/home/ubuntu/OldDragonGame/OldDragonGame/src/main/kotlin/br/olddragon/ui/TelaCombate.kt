package br.olddragon.ui

import br.olddragon.model.personagem.Personagem
import br.olddragon.service.CombateService
import java.util.Scanner

class TelaCombate(private val combateService: CombateService) {

    private val scanner = Scanner(System.`in`)

    fun iniciarCombate(personagem1: Personagem, personagem2: Personagem) {
        println("\n--- INICIANDO COMBATE ---")
        println("${personagem1.nome} vs ${personagem2.nome}")

        var turno = 1
        while (personagem1.pontosVida > 0 && personagem2.pontosVida > 0) {
            println("\n--- Turno $turno ---")
            println(combateService.atacar(personagem1, personagem2))
            // Lógica de dano e PV aqui
            // Exemplo simplificado: personagem2.pontosVida -= 1

            if (personagem2.pontosVida > 0) {
                println(combateService.atacar(personagem2, personagem1))
                // Lógica de dano e PV aqui
                // Exemplo simplificado: personagem1.pontosVida -= 1
            }
            turno++
            println("Pressione ENTER para o próximo turno...")
            scanner.nextLine()
        }

        println("\n--- FIM DO COMBATE ---")
        if (personagem1.pontosVida <= 0) {
            println("${personagem2.nome} venceu!")
        } else {
            println("${personagem1.nome} venceu!")
        }
    }
}


