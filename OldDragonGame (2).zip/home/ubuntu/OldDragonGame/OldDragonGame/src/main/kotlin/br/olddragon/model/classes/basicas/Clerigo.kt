package br.olddragon.model.classes.basicas

import br.olddragon.model.classes.ClasseBase
import br.olddragon.model.classes.TipoClasse
import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Clerigo : ClasseBase {
    override val tipo: TipoClasse = TipoClasse.CLERIGO
    override val dadoVida: String = "1d6"
    override val ataqueBase: Int = 0
    override val jogadaProtecao: Int = 16
    override val habilidades: List<String> = listOf("Conjuração de Magias Divinas")
    override val especializacao: EspecializacaoClasse? = null
}


