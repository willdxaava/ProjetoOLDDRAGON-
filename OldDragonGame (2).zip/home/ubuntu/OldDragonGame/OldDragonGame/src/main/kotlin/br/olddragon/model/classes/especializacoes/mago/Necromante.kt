package br.olddragon.model.classes.especializacoes.mago

import br.olddragon.model.classes.especializacoes.EspecializacaoClasse

class Necromante : EspecializacaoClasse {
    override val nomePortugues: String = "Necromante"
    override val habilidades: List<String> = listOf("Magias de Necromancia", "Controle de Mortos-Vivos")
}


