package br.olddragon

import br.olddragon.model.personagem.Raca
import br.olddragon.model.classes.basicas.Guerreiro
import br.olddragon.model.classes.basicas.Clerigo
import br.olddragon.model.classes.basicas.Ladrao
import br.olddragon.model.classes.basicas.Mago
import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Test

class ClassesTest {

    @Test
    fun `Raca Humano deve retornar 'Humano'`() {
        assertEquals("Humano", Raca.HUMANO.nomePortugues)
    }

    @Test
    fun `Raca Elfo deve retornar 'Elfo'`() {
        assertEquals("Elfo", Raca.ELFO.nomePortugues)
    }

    @Test
    fun `Raca Anao deve retornar 'Anão'`() {
        assertEquals("Anão", Raca.ANAO.nomePortugues)
    }

    @Test
    fun `Raca Halfling deve retornar 'Halfling'`() {
        assertEquals("Halfling", Raca.HALFLING.nomePortugues)
    }

    @Test
    fun `Classe Guerreiro deve retornar 'Guerreiro' e ter dado de vida 1d8`() {
        val guerreiro = Guerreiro()
        assertEquals("Guerreiro", guerreiro.tipo.nomePortugues)
        assertEquals("1d8", guerreiro.dadoVida)
    }

    @Test
    fun `Classe Clerigo deve retornar 'Clérigo' e ter dado de vida 1d6`() {
        val clerigo = Clerigo()
        assertEquals("Clérigo", clerigo.tipo.nomePortugues)
        assertEquals("1d6", clerigo.dadoVida)
    }

    @Test
    fun `Classe Ladrao deve retornar 'Ladrão' e ter dado de vida 1d4`() {
        val ladrao = Ladrao()
        assertEquals("Ladrão", ladrao.tipo.nomePortugues)
        assertEquals("1d4", ladrao.dadoVida)
    }

    @Test
    fun `Classe Mago deve retornar 'Mago' e ter dado de vida 1d4`() {
        val mago = Mago()
        assertEquals("Mago", mago.tipo.nomePortugues)
        assertEquals("1d4", mago.dadoVida)
    }
}


