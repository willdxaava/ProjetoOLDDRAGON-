package br.olddragon

import br.olddragon.model.utils.Dado
import org.junit.jupiter.api.Assertions.assertTrue
import org.junit.jupiter.api.Test

class DadoODTest {

    @Test
    fun `rolarD6 deve retornar um valor entre 3 e 18 para 3d6`() {
        val resultado = Dado.rolarD6(3)
        assertTrue(resultado >= 3 && resultado <= 18, "O resultado de 3d6 deve estar entre 3 e 18")
    }

    @Test
    fun `rolar4d6DescartaMenor deve retornar um valor entre 3 e 18`() {
        val resultado = Dado.rolar4d6DescartaMenor()
        assertTrue(resultado >= 3 && resultado <= 18, "O resultado de 4d6 descartando o menor deve estar entre 3 e 18")
    }
}


